export interface IForgotPasswordModel {
    mobileNumber: string;
}