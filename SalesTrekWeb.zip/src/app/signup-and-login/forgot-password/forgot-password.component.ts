import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { ToastService } from 'src/app/services/toast.service';
import { IForgotPasswordModel } from './forgot-password-model';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  mobileNumber: string = "";
  submitted: boolean = false;
  loading: boolean = false;
  forgotPassword = {} as IForgotPasswordModel;

  constructor(private http: LoginService, private _formBuilder: FormBuilder, private toastService: ToastService, private router: Router) { }

  ngOnInit(): void {
  }

  SendOTP(f: NgForm) {
    this.submitted = true;
    this.loading = true;
    this.forgotPassword = { mobileNumber: this.mobileNumber };
    this.http.postData("api/SalesTrekServices/ForgotPassword", this.forgotPassword).subscribe(
      (data: any) => {
        this.loading = false;
        this.submitted = false;
        if (data['statusCode'] == 204) {
          this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'OTP Status');
        }
        else if (data['statusCode'] == 200) {
          sessionStorage.setItem("phoneNumber", this.mobileNumber);
          sessionStorage.setItem("otp", data['data']);
          this.toastService.ShowToaster(data['message'] + "-" + data["data"], 'bg-success text-light', 'OTP Status');
          this.router.navigate(['/verify-reset-password-otp']);
        }

      },
      err => {
        this.loading = false;
        this.submitted = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
      }
    );
  }

}
