import { JwtHelperService } from '@auth0/angular-jwt';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { ToastService } from 'src/app/services/toast.service';
import { ICompanyModel } from '../create-company/company-model';
import { ILoginModel } from './login-model';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login = {} as ILoginModel;
  loginFormGroup: FormGroup;
  loading = false;
  submitted = false;
  status = false;

  isCapital = false;
  isSmall = false;
  isDigit = false;
  isSpecial = false;
  Length = 0;
  password = "";
  selectedCompany = {} as ICompanyModel;
  companies = [] as ICompanyModel[];
  _returnUrl: string;

  constructor(private http: LoginService, private http2: HttpService, private _formBuilder: FormBuilder, private toastService: ToastService, private router: Router, private activatedRoute: ActivatedRoute) {
    this.loginFormGroup = this._formBuilder.group({
      'mobileNumber': [null, [Validators.required]],
      'password': [null, [Validators.required]],
    });
    this._returnUrl = this.activatedRoute.snapshot.queryParams['returnUrl'] || '/';
  }

  ngOnInit(): void {
  }

  get f() { return this.loginFormGroup.controls; }

  onKeyUp(x: any) {
    this.isCapital = false;
    this.isSmall = false;
    this.isDigit = false;
    this.isSpecial = false;
    this.Length = 0;
    this.password = x.target.value;
    this.Length = this.password.length;
    for (let i = 0; i < this.password.length; i++) {
      let char = this.password.charCodeAt(i);
      if (char >= 48 && char <= 57)
        this.isDigit = true;
      else if (char >= 65 && char <= 90)
        this.isCapital = true;
      else if (char >= 97 && char <= 122)
        this.isSmall = true;
      else
        this.isSpecial = true;
    }
  }

  LoginUser(login: FormGroup) {
    this.loading = true;
    this.submitted = true;
    if (this.loginFormGroup.invalid) {
      this.loading = false;
      return;
    }
    this.login = login.value;
    this.http.postData("api/SalesTrekServices/PostVerifyUserLoginWeb", this.login).subscribe(
      (data: any) => {
        this.loading = false;
        this.submitted = false;
        if (data['statusCode'] == 204) {
          this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'Login Status');
        }
        else if (data['statusCode'] == 200) {
          this.loginFormGroup.reset();
          if (typeof (data['data']) == "string") {
            localStorage.setItem("tempToken", data['data']);
            localStorage.setItem("jwtToken", data['data']);
            let jwtHelper = new JwtHelperService();
            let token = jwtHelper.decodeToken(data['data']);
            if (token.companyId == "") {
              this.toastService.ShowToaster(data['message'] + " - Create a Company", 'bg-success text-light', 'Login Status');
              this.router.navigate(['/create-company']);
            }
            else if (token.status == "Expired" || token.status == "Not Subscribed") {
              this.toastService.ShowToaster(data['message'] + " - Subscribe to a plan", 'bg-success text-light', 'Login Status');
              this.router.navigate(['/plan-subscription']);
            }
            else {
              localStorage.setItem("jwtToken", data['data']);
              this.http2.getDataNoParam("api/SalesTrekServices/GetGroupsCount").subscribe(
                data => {
                  if (data['statusCode'] == 200) {
                    if (data['data'] == 0) {
                      this.router.navigate(['/admin/create-project']);
                    }
                    else {
                      this.router.navigate(['/admin']);
                    }
                  }

                }
              );

            }
          }
          else {
            this.companies = data['data'];
            this.status = true;
          }
        }
      },
      err => {
        this.loading = false;
        this.submitted = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
      }
    );
  }

  onItemChange(item: ICompanyModel) {
    this.selectedCompany = item;
  }
  LoginWithSelectedCompany() {
    this.http.postData("api/SalesTrekServices/LoginWithSelectedCompanyWeb", this.selectedCompany).subscribe(
      (data: any) => {
        if (data['statusCode'] == 204) {
          this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'Login Status');
        }
        else if (data['statusCode'] == 200) {
          localStorage.setItem("tempToken", data['data']);
          let jwtHelper = new JwtHelperService();
          let token = jwtHelper.decodeToken(data['data']);
          if (token.status == "Expired" || token.status == "Not Subscribed") {
            this.toastService.ShowToaster(data['message'] + " - Subscribe to a Plan", 'bg-success text-light', 'Login Status');
            this.router.navigate(['/plan-subscription']);
          }
          else {
            localStorage.setItem("jwtToken", data['data']);
            this.router.navigate(['/admin']);
          }
        }
      },
      err => {
        this.loading = false;
        this.submitted = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
      });
  }
}


