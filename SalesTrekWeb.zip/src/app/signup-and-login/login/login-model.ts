export interface ILoginModel {
    mobileNumber: string;
    password: string;
}