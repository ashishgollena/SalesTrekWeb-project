import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';
import { LoginService } from 'src/app/services/login.service';
import { ToastService } from 'src/app/services/toast.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-send-otp',
  templateUrl: './send-otp.component.html',
  styleUrls: ['./send-otp.component.css']
})
export class SendOTPComponent implements OnInit {

  mobileNumber: string = "";
  submitted: boolean = false;
  loading: boolean = false;

  constructor(private http: LoginService, private _formBuilder: FormBuilder, private toastService: ToastService, private router: Router) {
  }

  ngOnInit(): void {
  }

  SendOTP(f: NgForm) {
    this.submitted = true;
    this.loading = true;
    this.http.getData("api/SalesTrekServices/SendOTP", "mobileNumber", this.mobileNumber).subscribe(
      (data: any) => {
        this.loading = false;
        this.submitted = false;
        if (data['statusCode'] == 204) {
          this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'OTP Status');
        }
        else if (data['statusCode'] == 200) {
          sessionStorage.setItem("phoneNumber", this.mobileNumber);
          sessionStorage.setItem("otp", data['data']);
          this.toastService.ShowToaster(data['message'] + "-" + data["data"], 'bg-success text-light', 'OTP Status');
          this.router.navigate(['/verify-OTP']);
        }

      },
      err => {
        this.loading = false;
        this.submitted = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
      }
    );
  }
}


