import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SendOTPRoutingModule } from './send-otp-routing.module';
import { SendOTPComponent } from './send-otp.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [SendOTPComponent],
  imports: [
    CommonModule,
    SendOTPRoutingModule,
    FormsModule,
    SharedModule
  ]
})
export class SendOTPModule { }
