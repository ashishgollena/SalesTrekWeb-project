import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PlanSubscriptionRoutingModule } from './plan-subscription-routing.module';
import { PlanSubscriptionComponent } from './plan-subscription.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    PlanSubscriptionComponent
  ],
  imports: [
    CommonModule,
    PlanSubscriptionRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class PlanSubscriptionModule { }
