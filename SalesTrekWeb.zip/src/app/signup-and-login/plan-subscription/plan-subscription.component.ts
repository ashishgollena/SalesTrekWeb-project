import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { forkJoin } from 'rxjs';
import { HttpService } from 'src/app/services/http.service';
import { ToastService } from 'src/app/services/toast.service';
import { IBuiltPlan, ICompanySubscription, ISubscriptionPlan } from './plan-models';

@Component({
  selector: 'app-plan-subscription',
  templateUrl: './plan-subscription.component.html',
  styleUrls: ['./plan-subscription.component.css']
})
export class PlanSubscriptionComponent implements OnInit {

  buildPlan = {} as IBuiltPlan;
  companySubscription = {} as ICompanySubscription;
  subscriptionPlan = {} as ISubscriptionPlan;
  subscriptionPlans = [] as ISubscriptionPlan[];
  buildPlanFormGroup: FormGroup;
  loading = false;
  submitted = false;
  oldUsers = 0;
  noOfMonths = 0;
  status = "";
  expiredUsers = 0;


  constructor(private http: HttpService, private _formBuilder: FormBuilder, private toastService: ToastService, private router: Router, private activatedRoute: ActivatedRoute) {
    this.buildPlanFormGroup = this._formBuilder.group({
      builtPlanId: [0],
      planId: [this.subscriptionPlan.planId],
      userId: [null],
      noOfUsers: [0, Validators.required],
      usersFee: [0, Validators.required],
      advisoryFee: [0, Validators.required],
      gstamount: [0, Validators.required],
      grossAmount: [0],
      discountCoupon: [null],
      discountAmount: [0],
      netAmount: [0, Validators.required],
      companyId: [null],
      status: [0],
      createdDate: [null],
      createdBy: [null],
      paidDate: [null],
      paidBy: [null]
    });
  }

  ngOnInit(): void {
    this.LoadPLans();
  }

  LoadPLans() {
    forkJoin([this.http.getSubsription("api/SalesTrekServices/GetAllPlans"),
    this.http.getSubsription("api/SalesTrekServices/GetUnpaidBuildPlan"),
    this.http.getSubsription("api/SalesTrekServices/SubscriptionDetailsByCompany")
    ]).subscribe(
      data => {
        this.subscriptionPlan = data[0]['data'][0];
        if (data[2]['data'] != null)
          this.companySubscription = data[2]['data'][0];
        if (data[1]['data'] != null) {
          this.buildPlan = data[1]['data'];
          this.buildPlanFormGroup = this._formBuilder.group(this.buildPlan);
        }
        this.buildPlanFormGroup.patchValue(this.subscriptionPlan);
        let token = new JwtHelperService().decodeToken(localStorage.getItem("tempToken") as string);
        this.status = token.status;
        this.CalculateAmounts(this.buildPlanFormGroup);
      },
      err => {
        this.loading = false;
        this.submitted = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
      }
    );
  }

  CalculateAmounts(form: FormGroup) {
    this.loading = true;
    this.submitted = true;
    if (this.buildPlanFormGroup.invalid) {
      this.loading = false;
      return;
    }
    this.buildPlan = form.value;
    console.log(this.buildPlan);

    if (this.companySubscription == null || this.companySubscription == undefined) {
      if (form.value.noOfUsers == 0)
        this.buildPlan.noOfUsers = 0;

      if (this.buildPlan.noOfUsers == 0)
        this.buildPlan.advisoryFee = 0;
      else if (this.buildPlan.noOfUsers > 0 && this.buildPlan.noOfUsers <= 5)
        this.buildPlan.advisoryFee = 5000;
      else if (this.buildPlan.noOfUsers > 5 && this.buildPlan.noOfUsers <= 15)
        this.buildPlan.advisoryFee = 15000;
      else if (this.buildPlan.noOfUsers > 15 && this.buildPlan.noOfUsers <= 50)
        this.buildPlan.advisoryFee = 30000;
      else {
        this.buildPlan.advisoryFee = 50000;
      }
      this.buildPlan.usersFee = 1200 * this.buildPlan.noOfUsers;
      this.buildPlan.gstamount = (this.buildPlan.usersFee + this.buildPlan.advisoryFee) * (0.12);
      this.buildPlan.grossAmount = this.buildPlan.usersFee + this.buildPlan.advisoryFee + this.buildPlan.gstamount;
      this.buildPlan.netAmount = this.buildPlan.grossAmount - this.buildPlan.discountAmount;
      this.buildPlanFormGroup = this._formBuilder.group(this.buildPlan);
    }
    else if (this.status == "Expired" || this.status == "OnHold") {
      this.buildPlan.noOfUsers = this.companySubscription.noOfUsers;
      if (this.buildPlan.noOfUsers == 0)
        this.buildPlan.advisoryFee = 0;
      else if (this.buildPlan.noOfUsers > 0 && this.buildPlan.noOfUsers <= 5)
        this.buildPlan.advisoryFee = 5000;
      else if (this.buildPlan.noOfUsers > 5 && this.buildPlan.noOfUsers <= 15)
        this.buildPlan.advisoryFee = 15000;
      else if (this.buildPlan.noOfUsers > 15 && this.buildPlan.noOfUsers <= 50)
        this.buildPlan.advisoryFee = 30000;
      else {
        this.buildPlan.advisoryFee = 50000;
      }
      this.buildPlan.usersFee = 1200 * this.buildPlan.noOfUsers;
      this.buildPlan.gstamount = (this.buildPlan.usersFee + this.buildPlan.advisoryFee) * (0.12);
      this.buildPlan.grossAmount = this.buildPlan.usersFee + this.buildPlan.advisoryFee + this.buildPlan.gstamount;
      this.buildPlan.netAmount = this.buildPlan.grossAmount - this.buildPlan.discountAmount;
      this.buildPlanFormGroup = this._formBuilder.group(this.buildPlan);
    }
    else {
      this.oldUsers = this.companySubscription.noOfUsers;
      let totalUsers = this.buildPlan.noOfUsers + this.companySubscription.noOfUsers;
      if (totalUsers <= 5) {
        this.buildPlan.advisoryFee = 0;
      }
      else if (totalUsers > 5 && totalUsers <= 15) {
        if (this.companySubscription.noOfUsers <= 5)
          this.buildPlan.advisoryFee = 10000;
        else
          this.buildPlan.advisoryFee = 0;
      }
      else if (totalUsers > 15 && totalUsers <= 30) {
        if (this.companySubscription.noOfUsers <= 5)
          this.buildPlan.advisoryFee = 25000;
        else if (this.companySubscription.noOfUsers > 5 && this.companySubscription.noOfUsers <= 15)
          this.buildPlan.advisoryFee = 15000;
        else
          this.buildPlan.advisoryFee = 0;
      }
      else {
        if (this.companySubscription.noOfUsers <= 5)
          this.buildPlan.advisoryFee = 45000;
        else if (this.companySubscription.noOfUsers > 5 && this.companySubscription.noOfUsers <= 15)
          this.buildPlan.advisoryFee = 35000;
        else if (this.companySubscription.noOfUsers > 15 && this.companySubscription.noOfUsers <= 50)
          this.buildPlan.advisoryFee = 20000;
        else
          this.buildPlan.advisoryFee = 0;
      }
      /* Number of Months calculation */
      let date1 = new Date(this.companySubscription.endDate);
      let date2 = new Date();
      let timeInMilisec: number = date1.getTime() - date2.getTime();
      let daysBetweenDates: number = Math.ceil(timeInMilisec / (1000 * 60 * 60 * 24));
      this.noOfMonths = Math.ceil(daysBetweenDates / 30);

      this.buildPlan.usersFee = this.noOfMonths * 100 * this.buildPlan.noOfUsers;
      this.buildPlan.gstamount = (this.buildPlan.usersFee + this.buildPlan.advisoryFee) * (0.12);
      this.buildPlan.grossAmount = this.buildPlan.usersFee + this.buildPlan.advisoryFee + this.buildPlan.gstamount;
      this.buildPlan.netAmount = this.buildPlan.grossAmount - this.buildPlan.discountAmount;
      this.buildPlanFormGroup = this._formBuilder.group(this.buildPlan);
    }
    this.loading = false;
    this.submitted = false;
  }

  SaveAndPayLater(status: boolean) {
    this.loading = true;
    this.submitted = true;
    if (this.buildPlanFormGroup.invalid) {
      this.loading = false;
      return;
    }
    this.buildPlan.status = status;
    this.buildPlan.companyId = 0;
    this.http.postSubscription("api/SalesTrekServices/BuildYourPlan", this.buildPlan).subscribe(
      data => {
        this.toastService.ShowToaster(data['message'], 'bg-success text-light', 'Build Plan Status');
        this.loading = false;
        this.submitted = false;
      },
      err => {
        this.loading = false;
        this.submitted = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'Build Plan Status');
      }
    );
  }

  ProceedToPay() {
    debugger;
    this.loading = true;
    this.submitted = true;
    if (this.buildPlanFormGroup.invalid) {
      this.loading = false;
      return;
    }
    this.buildPlan.status = true;
    this.buildPlan.companyId = 0;

    console.log(this.buildPlan);

    if (this.companySubscription == undefined) {
      this.companySubscription = {} as ICompanySubscription;
      this.companySubscription.subscriptionId = 0;
      this.companySubscription.planName = this.subscriptionPlan.planName;
      this.companySubscription.pricePerUser = this.subscriptionPlan.pricePerUser;
      this.companySubscription.noOfUsers = this.buildPlan.noOfUsers;
      this.companySubscription.subscriptionAmount = this.buildPlan.netAmount;
      this.companySubscription.companyId = 0;
      this.companySubscription.status = "Active";
    }
    else {
      if (this.status == "Expired" || this.status == "OnHold") {
        this.companySubscription.noOfUsers = this.buildPlan.noOfUsers;
        this.companySubscription.subscriptionAmount = this.buildPlan.netAmount;
        this.companySubscription.startDate = this.companySubscription.endDate;
      }
      else {
        this.companySubscription.noOfUsers += this.buildPlan.noOfUsers;
        this.companySubscription.subscriptionAmount += this.buildPlan.netAmount;
      }
    }

    forkJoin([this.http.postSubscription("api/SalesTrekServices/BuildYourPlan", this.buildPlan),
    this.http.postSubscription("api/SalesTrekServices/SubscribeToPlan", this.companySubscription),
    ]).subscribe(data => {
      this.toastService.ShowToaster(data[1]['message'], 'bg-success text-light', 'Build Plan Status');
      this.loading = false;
      this.submitted = false;
      this.router.navigate(['/']);
    },
      err => {
        this.loading = false;
        this.submitted = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'Build Plan Status');
      });

  }
}
