
export interface ISubscriptionPlan {
    planId: number;
    planName: string;
    period: string;
    pricePerUser: number;
    noOfLeads: number;
    gST_Percentage: number;
    status: boolean;
}
export interface IBuiltPlan {
    builtPlanId: number;
    planId: number;
    userId: string;
    noOfUsers: number;
    usersFee: number;
    advisoryFee: number;
    gstamount: number;
    grossAmount: number;
    discountCoupon: string;
    discountAmount: number;
    netAmount: number;
    companyId: number;
    status: boolean;
    createdDate: string;
    createdBy: string;
    paidDate: string;
    paidBy: string;
}
export interface ICompanySubscription {
    subscriptionId: number;
    planName: string;
    pricePerUser: number;
    startDate: string;
    endDate: string;
    noOfUsers: number;
    activeUsres: number;
    status: string;
    subscriptionAmount: number;
    companyId: number;
}
