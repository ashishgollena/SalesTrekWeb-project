import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlanSubscriptionComponent } from './plan-subscription.component';

const routes: Routes = [
  { path: '', component: PlanSubscriptionComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlanSubscriptionRoutingModule { }
