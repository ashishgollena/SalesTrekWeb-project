import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SignupAndLoginRoutingModule } from './signup-and-login-routing.module';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule,
    SignupAndLoginRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: []
})
export class SignupAndLoginModule { }
