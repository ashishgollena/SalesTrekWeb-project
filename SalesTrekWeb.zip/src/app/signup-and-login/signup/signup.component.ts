import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpService } from 'src/app/services/http.service';
import { LoginService } from 'src/app/services/login.service';
import { ToastService } from 'src/app/services/toast.service';
import { IUserModel } from './user-signup-model';
declare var $: any;

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  userDetails = {} as IUserModel
  signupFormGroup: FormGroup;
  loading = false;
  submitted = false;

  isCapital = false;
  isSmall = false;
  isDigit = false;
  isSpecial = false;
  Length = 0;
  password = "";

  constructor(private http: LoginService, private _formBuilder: FormBuilder, private toastService: ToastService) {
    this.signupFormGroup = this._formBuilder.group({
      'fullName': [null, [Validators.required]],
      'email': [null, [Validators.required, Validators.email]],
      'phoneNumber': [null, [Validators.required, Validators.minLength, Validators.maxLength]],
      'password': [null, [Validators.required]],
      'userName': [null]
    });
  }

  ngOnInit(): void {
  }


  get f() { return this.signupFormGroup.controls; }

  onKeyUp(x: any) {
    this.isCapital = false;
    this.isSmall = false;
    this.isDigit = false;
    this.isSpecial = false;
    this.Length = 0;
    this.password = x.target.value;
    this.Length = this.password.length;
    for (let i = 0; i < this.password.length; i++) {
      let char = this.password.charCodeAt(i);
      if (char >= 48 && char <= 57)
        this.isDigit = true;
      else if (char >= 65 && char <= 90)
        this.isCapital = true;
      else if (char >= 97 && char <= 122)
        this.isSmall = true;
      else
        this.isSpecial = true;
    }
  }

  SignupUser(signup: FormGroup) {
    this.submitted = true;
    this.loading = true;
    if (this.signupFormGroup.invalid) {
      this.loading = false;
      return;
    }

    if (signup.valid) {
      this.userDetails = this.signupFormGroup.value;
      this.userDetails.userName = this.userDetails.email;
      this.http.postData("api/SalesTrekServices/PostRegisterOrgAdmin", this.userDetails).subscribe(
        (data: any) => {
          this.loading = false;
          this.submitted = false;

          if (data['statusCode'] == 204) {
            this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'Registration Status');
          }
          else if (data['statusCode'] == 200) {
            this.signupFormGroup.reset();
            this.toastService.ShowToaster(data['message'], 'bg-success text-light', 'Registration Status');
          }
        },
        err => {
          this.loading = false;
          this.submitted = false;
          this.toastService.ShowToaster(err, 'bg-danger text-light', 'Registration Status');
        }
      );
    }
  }
}
