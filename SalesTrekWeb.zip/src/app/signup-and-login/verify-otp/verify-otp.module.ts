import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VerifyOTPRoutingModule } from './verify-otp-routing.module';
import { VerifyOTPComponent } from './verify-otp.component';

import { AngularOtpLibModule } from 'angular-otp-box';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
  declarations: [VerifyOTPComponent],
  imports: [
    CommonModule,
    VerifyOTPRoutingModule,
    AngularOtpLibModule,
    SharedModule
  ],
  exports: [VerifyOTPComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class VerifyOTPModule { }
