export interface IOTPModel {
    phone: string;
    token: string;
}