import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { LoginService } from 'src/app/services/login.service';
import { ToastService } from 'src/app/services/toast.service';
import { ICompanyModel } from '../create-company/company-model';
import { IOTPModel } from './otp-model';

@Component({
  selector: 'app-verify-otp',
  templateUrl: './verify-otp.component.html',
  styleUrls: ['./verify-otp.component.css']
})
export class VerifyOTPComponent implements OnInit {

  mobileNumber: any;
  otpModel = {} as IOTPModel;
  selectedCompany = {} as ICompanyModel;
  loading = false;

  public settings = {
    length: 6,
    numbersOnly: true,
    timer: 10,
    timerType: 1
  }
  num: string | null;
  phoneNumber: string;
  companies = [] as ICompanyModel[];
  status = false;
  otp: any;

  constructor(private http: LoginService, private _formBuilder: FormBuilder, private toastService: ToastService, private router: Router) {
    this.mobileNumber = sessionStorage.getItem("phoneNumber");
    this.num = sessionStorage.getItem("phoneNumber");
    this.otp = sessionStorage.getItem("otp");
    this.phoneNumber = "";
    if (this.num == null)
      this.phoneNumber = "";
    else
      this.phoneNumber = this.num.toString();
  }

  ngOnInit(): void {

  }


  public onInputChange(e: any) {
    if (e.length == this.settings.length) {

      this.otpModel = { phone: this.phoneNumber, token: e };
      this.http.postData("api/SalesTrekServices/VerifyOTPWeb", this.otpModel).subscribe(
        (data: any) => {
          if (data['statusCode'] == 204) {
            this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'OTP Status');
          }
          else if (data['statusCode'] == 200) {
            if (typeof (data['data']) == "string") {
              localStorage.setItem("tempToken", data['data']);
              let jwtHelper = new JwtHelperService();
              let token = jwtHelper.decodeToken(data['data']);
              if (token.companyId == "") {
                this.toastService.ShowToaster(data['message'] + " - Create a Company", 'bg-success text-light', 'Login Status');
                this.router.navigate(['/create-company']);
              }
              else if (token.status == "Expired" || token.status == "Not Subscribed") {
                this.toastService.ShowToaster(data['message'] + " - Subscribe to a plan", 'bg-success text-light', 'Login Status');
                this.router.navigate(['/plan-subscription']);
              }
              else {
                localStorage.setItem("jwtToken", data['data']);
                this.router.navigate(['/admin']);
              }
            }
            else {
              this.companies = data['data'];
              this.status = true;
            }
          }
        },
        err => {
          if (err instanceof HttpErrorResponse) {
            this.toastService.ShowToaster(err['error']['message'], 'bg-danger text-light', 'OTP Status');
          }
        }
      );

    } else if (e == -1) {
      // if e == -1, timer has stopped
    } else if (e == -2) {
      // e == -2, button click handle

      this.http.getData("api/SalesTrekServices/SendOTP", "mobileNumber", this.phoneNumber).subscribe(
        (data: any) => {
          if (data['statusCode'] == 204) {
            this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'OTP Status');
          }
          else if (data['statusCode'] == 200) {
            this.toastService.ShowToaster(data['message'], 'bg-success text-light', 'OTP Status');
            this.otp = data['data'];
          }
        },
        err => {
          this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
        }
      );
    }
  }

  onItemChange(item: ICompanyModel) {
    this.selectedCompany = item;
  }
  LoginWithSelectedCompany() {
    this.loading = true;
    this.http.postData("api/SalesTrekServices/LoginWithSelectedCompanyWeb", this.selectedCompany).subscribe(
      (data: any) => {
        if (data['statusCode'] == 204) {
          this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'OTP Status');
        }
        else if (data['statusCode'] == 200) {
          localStorage.setItem("tempToken", data['data']);
          let jwtHelper = new JwtHelperService();
          let token = jwtHelper.decodeToken(data['data']);
          if (token.status == "Expired" || token.status == "Not Subscribed") {
            this.toastService.ShowToaster(data['message'] + " - Subscribe to a Plan", 'bg-success text-light', 'Login Status');
            this.router.navigate(['/plan-subscription']);
          }
          else {
            localStorage.setItem("jwtToken", data['data']);
            this.router.navigate(['/admin']);
          }

        }
      },
      err => {
        this.loading = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
      });
  }
}


