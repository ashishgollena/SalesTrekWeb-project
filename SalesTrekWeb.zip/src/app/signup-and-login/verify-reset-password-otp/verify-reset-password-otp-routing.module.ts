import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VerifyResetPasswordOtpComponent } from './verify-reset-password-otp.component';

const routes: Routes = [
  {
    path: '', component: VerifyResetPasswordOtpComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VerifyResetPasswordOtpRoutingModule { }
