import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VerifyResetPasswordOtpRoutingModule } from './verify-reset-password-otp-routing.module';
import { VerifyResetPasswordOtpComponent } from './verify-reset-password-otp.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule } from '@angular/forms';
import { AngularOtpLibModule } from 'angular-otp-box';


@NgModule({
  declarations: [
    VerifyResetPasswordOtpComponent
  ],
  imports: [
    CommonModule,
    VerifyResetPasswordOtpRoutingModule,
    AngularOtpLibModule,
    SharedModule,
    FormsModule
  ]
})
export class VerifyResetPasswordOtpModule { }
