import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { ToastService } from 'src/app/services/toast.service';
import { IForgotPasswordModel } from '../forgot-password/forgot-password-model';

@Component({
  selector: 'app-verify-reset-password-otp',
  templateUrl: './verify-reset-password-otp.component.html',
  styleUrls: ['./verify-reset-password-otp.component.css']
})
export class VerifyResetPasswordOtpComponent implements OnInit {
  mobileNumber: any;
  forgotPassword = {} as IForgotPasswordModel;

  public settings = {
    length: 6,
    numbersOnly: true,
    timer: 10,
    timerType: 1
  }
  num: string | null;
  phoneNumber: string;
  otp: any;

  constructor(private http: LoginService, private toastService: ToastService, private router: Router) {
    this.mobileNumber = sessionStorage.getItem("phoneNumber");
    this.num = sessionStorage.getItem("phoneNumber");
    this.otp = sessionStorage.getItem("otp");
    this.phoneNumber = "";
    if (this.num == null)
      this.phoneNumber = "";
    else
      this.phoneNumber = this.num.toString();
  }

  ngOnInit(): void {

  }


  public onInputChange(e: any) {
    if (e.length == this.settings.length) {
      this.http.getDataWith2Params("api/SalesTrekServices/VerifyResetPasswordOTP", "OTP", "mobile", e, this.phoneNumber).subscribe(
        (data: any) => {
          if (data['statusCode'] == 204) {
            this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'OTP Status');
          }
          else if (data['statusCode'] == 200) {
            this.toastService.ShowToaster(data['message'], 'bg-success text-light', 'OTP Status');
            this.router.navigate(['/reset-password']);
          }
        },
        err => {
          this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
        }
      );

    } else if (e == -1) {
      // if e == -1, timer has stopped
    } else if (e == -2) {
      // e == -2, button click handle
      this.forgotPassword = { mobileNumber: this.mobileNumber };
      this.http.postData("api/SalesTrekServices/ForgotPassword", this.forgotPassword).subscribe(
        (data: any) => {
          if (data['statusCode'] == 204) {
            this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'OTP Status');
          }
          else if (data['statusCode'] == 200) {
            this.toastService.ShowToaster(data['message'], 'bg-success text-light', 'OTP Status');
            this.otp = data['data'];
          }
        },
        err => {
          this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
        }
      );
    }
  }
}


