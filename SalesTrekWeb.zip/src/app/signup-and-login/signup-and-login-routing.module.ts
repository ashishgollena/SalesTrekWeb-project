import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('../signup-and-login/login/login.module').then(m => m.LoginModule)
  },
  {
    path: 'login',
    loadChildren: () => import('../signup-and-login/login/login.module').then(m => m.LoginModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('../signup-and-login/signup/signup.module').then(m => m.SignupModule)
  },
  {
    path: 'create-company',
    loadChildren: () => import('../signup-and-login/create-company/create-company.module').then(m => m.CreateCompanyModule)
  },
  {
    path: 'send-OTP',
    loadChildren: () => import('../signup-and-login/send-otp/send-otp.module').then(m => m.SendOTPModule)
  },
  {
    path: 'verify-OTP',
    loadChildren: () => import('../signup-and-login/verify-otp/verify-otp.module').then(m => m.VerifyOTPModule)
  },
  {
    path: 'forgot-password',
    loadChildren: () => import('../signup-and-login/forgot-password/forgot-password.module').then(m => m.ForgotPasswordModule)
  },
  {
    path: 'verify-reset-password-otp',
    loadChildren: () => import('../signup-and-login/verify-reset-password-otp/verify-reset-password-otp.module').then(m => m.VerifyResetPasswordOtpModule)
  },
  {
    path: 'reset-password',
    loadChildren: () => import('../signup-and-login/reset-password/reset-password.module').then(m => m.ResetPasswordModule)
  },
  {
    path: 'plan-subscription',
    loadChildren: () => import('../signup-and-login/plan-subscription/plan-subscription.module').then(m => m.PlanSubscriptionModule)
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SignupAndLoginRoutingModule { }
