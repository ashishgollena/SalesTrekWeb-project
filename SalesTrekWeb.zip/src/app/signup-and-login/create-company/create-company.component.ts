import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';
import { LoginService } from 'src/app/services/login.service';
import { ToastService } from 'src/app/services/toast.service';
import { ICompanyModel } from './company-model';

@Component({
  selector: 'app-create-company',
  templateUrl: './create-company.component.html',
  styleUrls: ['./create-company.component.css']
})
export class CreateCompanyComponent implements OnInit {

  company = {} as ICompanyModel;
  companyFormGroup: FormGroup;
  submitted: boolean = false;
  loading: boolean = false;

  constructor(private http: HttpService, private loginService: LoginService, private _formBuilder: FormBuilder, private toastService: ToastService, private router: Router) {
    this.companyFormGroup = this._formBuilder.group({
      'companyId': [0],
      'companyName': [null, [Validators.required]],
      'gstnumber': [null, [Validators.required]],
      'webUrl': [null],
      'id': [null],
      'mailId': [null]
    });
  }

  ngOnInit(): void {
  }

  get f() { return this.companyFormGroup.controls; }

  CreateCompany(company: FormGroup) {
    this.submitted = true;
    this.loading = true;
    if (this.companyFormGroup.invalid) {
      this.loading = false;
      return;
    }

    if (company.valid) {
      this.company = company.value;
      this.http.postData("api/SalesTrekServices/PostOrUpdateCompany", this.company).subscribe(
        (data: any) => {
          this.loading = false;
          this.submitted = false;
          console.log(data);

          if (data['statusCode'] == 204) {
            this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'Company Creation Status');
          }
          else if (data['statusCode'] == 200) {
            this.companyFormGroup.reset();
            this.toastService.ShowToaster(data['message'], 'bg-success text-light', 'Company Creation Status');
            this.loginService.logout();
            this.router.navigate(['/']);
          }

        },
        err => {
          this.loading = false;
          this.submitted = false;
          this.toastService.ShowToaster(err, 'bg-danger text-light', 'Company Creation Status');
        }
      );
    }
  }
}
