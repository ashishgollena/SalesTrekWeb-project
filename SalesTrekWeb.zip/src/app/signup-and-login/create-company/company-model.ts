export interface ICompanyModel {
    companyId: number;
    companyName: string;
    Gstnumber: string;
    WebUrl?: string;
    id?: string;
    mailId?: string;
}