export interface IResetPassword {
    password: string;
    confirmPassword: string;
    mobileNumber: string;
}