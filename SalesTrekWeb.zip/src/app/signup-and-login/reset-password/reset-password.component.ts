import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { ToastService } from 'src/app/services/toast.service';
import { MustMatch } from 'src/app/utilities/password-helper';
import { IResetPassword } from './reset-password-model';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  resetPassword = {} as IResetPassword;
  resetPasswordFormGroup: FormGroup;

  loading = false;
  submitted = false;
  num: any;
  phoneNumber: string;

  isCapital = false;
  isSmall = false;
  isDigit = false;
  isSpecial = false;
  Length = 0;
  password = "";

  constructor(private http: LoginService, private _formBuilder: FormBuilder, private toastService: ToastService, private router: Router) {
    this.resetPasswordFormGroup = this._formBuilder.group({
      'password': [null, [Validators.required]],
      'confirmPassword': [null, [Validators.required]],
      'mobileNumber': [null]
    },
      {
        validator: MustMatch('password', 'confirmPassword')
      });


    this.num = sessionStorage.getItem("phoneNumber");
    this.phoneNumber = "";
    if (this.num == null)
      this.phoneNumber = "";
    else
      this.phoneNumber = this.num.toString();
  }

  ngOnInit(): void {
  }

  get f() { return this.resetPasswordFormGroup.controls; }

  onKeyUp(x: any) {
    this.isCapital = false;
    this.isSmall = false;
    this.isDigit = false;
    this.isSpecial = false;
    this.Length = 0;
    this.password = x.target.value;
    this.Length = this.password.length;
    for (let i = 0; i < this.password.length; i++) {
      let char = this.password.charCodeAt(i);
      if (char >= 48 && char <= 57)
        this.isDigit = true;
      else if (char >= 65 && char <= 90)
        this.isCapital = true;
      else if (char >= 97 && char <= 122)
        this.isSmall = true;
      else
        this.isSpecial = true;
    }
  }


  ChangePassword(form: FormGroup) {
    this.submitted = true;
    this.loading = true;
    if (this.resetPasswordFormGroup.invalid) {
      this.loading = false;
      return;
    }
    this.resetPassword = this.resetPasswordFormGroup.value;
    this.resetPassword.mobileNumber = this.phoneNumber;
    this.http.postData("api/SalesTrekServices/ResetPassword", this.resetPassword).subscribe(
      (data: any) => {
        if (data['statusCode'] == 204) {
          this.toastService.ShowToaster(data['message'], 'bg-warning text-light', 'OTP Status');
        }
        else if (data['statusCode'] == 200) {
          this.toastService.ShowToaster(data['message'], 'bg-success text-light', 'OTP Status');
          this.http.logout();
          this.router.navigate(['/']);
        }
      },
      err => {
        this.loading = false;
        this.submitted = false;
        this.toastService.ShowToaster(err, 'bg-danger text-light', 'OTP Status');
      }
    );
  }
}
