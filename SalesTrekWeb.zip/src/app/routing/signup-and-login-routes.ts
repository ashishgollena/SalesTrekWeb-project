
import { Routes } from '@angular/router';

export const SIGNUPANDLOGIN_ROUTES: Routes = [
    {
        path: '',
        loadChildren: () => import('../signup-and-login/signup-and-login.module').then(m => m.SignupAndLoginModule)
    },
]
