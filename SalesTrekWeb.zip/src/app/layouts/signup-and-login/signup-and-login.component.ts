import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-and-login',
  templateUrl: './signup-and-login.component.html',
  styleUrls: ['./signup-and-login.component.css']
})
export class SignupAndLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
