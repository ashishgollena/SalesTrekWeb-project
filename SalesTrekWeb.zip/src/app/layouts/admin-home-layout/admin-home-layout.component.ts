import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-admin-home-layout',
  templateUrl: './admin-home-layout.component.html',
  styleUrls: ['./admin-home-layout.component.css']
})
export class AdminHomeLayoutComponent implements OnInit {

  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit(): void {
  }

  Logout() {
    this.loginService.logout();
    this.router.navigate(['/']);
  }

}
