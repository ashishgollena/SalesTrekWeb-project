import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupAndLoginComponent } from './layouts/signup-and-login/signup-and-login.component';
import { ToastComponent } from './shared/toast/toast.component';
import { AdminHomeLayoutComponent } from './layouts/admin-home-layout/admin-home-layout.component';
import { SharedModule } from './shared/shared.module';

import { AngularOtpLibModule } from 'angular-otp-box';
import { HttpService } from './services/http.service';
import { LoginService } from './services/login.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AuthGuard } from './utilities/auth.guard';


@NgModule({
  declarations: [
    AppComponent,
    SignupAndLoginComponent,
    ToastComponent,
    AdminHomeLayoutComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    SharedModule,
    AngularOtpLibModule,
    HttpClientModule
  ],
  providers: [LoginService, HttpService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
