import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminHomeLayoutComponent } from './layouts/admin-home-layout/admin-home-layout.component';
import { SignupAndLoginComponent } from './layouts/signup-and-login/signup-and-login.component';
import { ADMIN_ROUTES } from './routing/admin-routing';
import { SIGNUPANDLOGIN_ROUTES } from './routing/signup-and-login-routes';
import { AuthGuard } from './utilities/auth.guard';

const routes: Routes = [
  { path: '', component: SignupAndLoginComponent, children: SIGNUPANDLOGIN_ROUTES },
  { path: 'admin', component: AdminHomeLayoutComponent, children: ADMIN_ROUTES, canActivate: [AuthGuard] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
