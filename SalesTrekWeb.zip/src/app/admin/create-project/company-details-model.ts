export interface ICompanyDetails {
    companyId: number;
    companyName: string;
    Gstnumber: string;
    WebUrl?: string;
    id?: string;
    mailId?: string;
    status: boolean;
}