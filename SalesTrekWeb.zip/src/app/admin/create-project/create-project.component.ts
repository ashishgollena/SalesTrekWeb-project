import { Component, OnInit } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { HttpService } from 'src/app/services/http.service';
import { ICompanyDetails } from './company-details-model';

@Component({
  selector: 'app-create-project',
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.css']
})
export class CreateProjectComponent implements OnInit {

  userName: string | undefined;
  mobile: string | undefined;
  email: string | undefined;
  companyDetail = {} as ICompanyDetails;
  companiesDetails = [] as ICompanyDetails[];

  constructor(private http: HttpService) {
    let jwtHelper = new JwtHelperService();
    let token = jwtHelper.decodeToken(localStorage.getItem("jwtToken") as string);
    console.log(token);
    this.userName = token.name;
    this.mobile = token.actort;
    this.email = token.unique_name;
  }

  ngOnInit(): void {
    this.LoadCompanyDetails();
    this.LoadCompanySubscriptions();
  }

  LoadCompanyDetails() {
    this.http.getDataNoParam("api/SalesTrekServices/CompanyDetailsByUserId").subscribe(
      data => {
        if (data['statusCode'] == 200) {
          this.companiesDetails = data['data'];
        }
      }
    );
  }

  LoadCompanySubscriptions() {
    this.http.getDataNoParam("api/SalesTrekServices/CompanyDetailsByUserId").subscribe(
      data => {
        if (data['statusCode'] == 200) {
          this.companiesDetails = data['data'];
        }
      }
    );
  }
}
