import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-setup',
  templateUrl: './project-setup.component.html',
  styleUrls: ['./project-setup.component.css']
})
export class ProjectSetupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
