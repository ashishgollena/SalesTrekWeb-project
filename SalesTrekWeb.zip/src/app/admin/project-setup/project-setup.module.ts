import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectSetupRoutingModule } from './project-setup-routing.module';
import { ProjectSetupComponent } from './project-setup.component';


@NgModule({
  declarations: [
    ProjectSetupComponent
  ],
  imports: [
    CommonModule,
    ProjectSetupRoutingModule
  ]
})
export class ProjectSetupModule { }
