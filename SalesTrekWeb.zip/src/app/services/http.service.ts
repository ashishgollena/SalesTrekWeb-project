import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  ApiUrl = environment.ApiUrl;
  constructor(private http: HttpClient) { }

  //get method without parameter
  public getDataNoParam(apiUrl: string): Observable<any> {
    let token = localStorage.getItem("jwtToken");
    const headers = new HttpHeaders({ "Authorization": "Bearer " + token });
    const options = { headers: headers };
    return this.http.get(`${this.ApiUrl}${apiUrl}`, options).pipe(
      catchError(this.handleError));
  }

  //get subscription
  public getSubsription(apiUrl: string): Observable<any> {
    let token = localStorage.getItem("tempToken");
    const headers = new HttpHeaders({ "Authorization": "Bearer " + token });
    const options = { headers: headers };
    return this.http.get(`${this.ApiUrl}${apiUrl}`, options).pipe(
      catchError(this.handleError));
  }

  //get method with parameter
  public getData(apiUrl: string, parameterName: string, parameterValue: string): Observable<any> {
    let token = localStorage.getItem("jwtToken");
    const headers = new HttpHeaders({ "Authorization": "Bearer " + token });
    const options = { headers: headers, params: new HttpParams().set(parameterName, parameterValue) };
    return this.http.get(`${this.ApiUrl}${apiUrl}`, options).pipe(
      catchError(this.handleError));
  }

  //Post method to insert data
  public postData(apiUrl: string, data: any): Observable<any> {
    let token = localStorage.getItem("jwtToken");
    const headers = new HttpHeaders({ "Authorization": "Bearer " + token });
    return this.http.post(`${this.ApiUrl}${apiUrl}`, data, { headers: headers }).pipe(
      catchError(this.handleError)
    );
  }

  //Post method to subscribe
  public postSubscription(apiUrl: string, data: any): Observable<any> {
    let token = localStorage.getItem("tempToken");
    const headers = new HttpHeaders({ "Authorization": "Bearer " + token });
    return this.http.post(`${this.ApiUrl}${apiUrl}`, data, { headers: headers }).pipe(
      catchError(this.handleError)
    );
  }

  handleError(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error instanceof HttpErrorResponse) {
      if (error['statusText'] == 'Unknown Error') {
        errorMessage = "Server not available try after sometime";
      }
      else {
        if (error['error']['statusCode'] == 404) {
          errorMessage = error['error']['message'];
        }
        else if (error['error']['statusCode'] == 400) {
          errorMessage = error['error']['message'] + " - " + error['error']['errors'];
        }
        else if (error['error']['statusCode'] == 401) {
          errorMessage = error['error']['message'];
        }
      }
    }
    return throwError(errorMessage);
  }
}

