import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  ApiUrl = environment.ApiUrl;

  constructor(private http: HttpClient) { }

  //Post method to insert data
  public postData(apiUrl: string, data: any): Observable<any> {
    return this.http.post(`${this.ApiUrl}${apiUrl}`, data).pipe(
      catchError(this.handleError)
    );;
  }

  //get method with parameter
  public getData(apiUrl: string, parameterName: string, parameterValue: string): Observable<any> {
    const options = { params: new HttpParams().set(parameterName, parameterValue) };
    return this.http.get(`${this.ApiUrl}${apiUrl}`, options).pipe(
      catchError(this.handleError)
    );;
  }

  //get method with 2 parameters
  public getDataWith2Params(apiUrl: string, parameterName1: string, parameterName2: string, parameterValue1: string, parameterValue2: string): Observable<any> {
    const options = { params: new HttpParams().set(parameterName1, parameterValue1).set(parameterName2, parameterValue2) };
    return this.http.get(`${this.ApiUrl}${apiUrl}`, options).pipe(
      catchError(this.handleError)
    );;
  }

  public logout() {
    sessionStorage.clear();
    localStorage.removeItem("jwtToken");
  }

  public isLoggedIn() {
    let jwtHelper = new JwtHelperService();
    let token = localStorage.getItem('jwtToken');
    if (!token)
      return false;
    let isExpired = jwtHelper.isTokenExpired(token);
    return !isExpired;
  }

  handleError(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error instanceof HttpErrorResponse) {
      if (error['statusText'] == 'Unknown Error') {
        errorMessage = "Server not available try after sometime";
      }
      else {
        if (error['error']['statusCode'] == 404) {
          errorMessage = error['error']['message'];
        }
        else if (error['error']['statusCode'] == 400) {
          errorMessage = error['error']['message'] + " - " + error['error']['errors'];
        }
        else if (error['error']['statusCode'] == 401) {
          errorMessage = error['error']['message'];
        }
      }
    }
    return throwError(errorMessage);
  }
}
