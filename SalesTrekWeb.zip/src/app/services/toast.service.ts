// toast.service.ts
import { Injectable, TemplateRef } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ToastService {

  toasts: any[] = [];

  // Push new Toasts to array with content and options
  show(textOrTpl: string | TemplateRef<any>, options: any = {}) {
    this.toasts.push({ textOrTpl, ...options });
  }

  // Callback method to remove Toast DOM element from view
  remove(toast: any) {
    this.toasts = this.toasts.filter(t => t !== toast);
  }

  ShowToaster(message: string, classname: string, headerText: string) {
    this.show(message, {
      classname: classname,
      delay: 5000,
      autohide: true,
      headertext: headerText
    });
  }
}
