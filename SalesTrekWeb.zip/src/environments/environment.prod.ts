export const environment = {
  production: true,
  ApiUrl: "https://salestrek.skilllens.com/"
};
